<?php
  date_default_timezone_set('Asia/Jakarta');
  echo $runTime = date(' D j M y | H:i:s');
?>