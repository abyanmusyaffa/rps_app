

    <script src="<?= base_url('assets/') ?>js/bootstrap.js" ></script>

</body>
</html>